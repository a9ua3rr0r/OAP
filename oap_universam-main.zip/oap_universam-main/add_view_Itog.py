import sys
import sqlite3
from PyQt5 import QtWidgets, uic
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QMainWindow, QApplication, QTableView, QPushButton,
    QDialog, QVBoxLayout, QLabel, QLineEdit, QDialogButtonBox, QMessageBox
)
from PyQt5.QtSql import QSqlDatabase, QSqlTableModel

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("Builds_designer.ui", self)

        self.db = sqlite3.connect("baseforshopuniversam.db")
        self.cursor = self.db.cursor()

        self.tableView: QTableView = self.findChild(QTableView, "tableView")

        self.button_view_products: QPushButton = self.findChild(QPushButton, "pushButton_view_products")
        self.button_view_manufacturers: QPushButton = self.findChild(QPushButton, "pushButton_view_manufacturers")
        self.button_view_groups: QPushButton = self.findChild(QPushButton, "pushButton_view_groups")
        self.button_add_product: QPushButton = self.findChild(QPushButton, "pushButton_add_product")
        self.button_add_group: QPushButton = self.findChild(QPushButton, "pushButton_add_group")
        self.button_add_manufacturer: QPushButton = self.findChild(QPushButton, "pushButton_add_manufacturer")
        self.button_delete_record: QPushButton = self.findChild(QPushButton, "pushButton_delete_record")

        self.button_view_products.clicked.connect(self.show_products)
        self.button_view_manufacturers.clicked.connect(self.show_manufacturers)
        self.button_view_groups.clicked.connect(self.show_groups)
        self.button_add_product.clicked.connect(self.add_product)
        self.button_add_group.clicked.connect(self.add_group)
        self.button_add_manufacturer.clicked.connect(self.add_manufacturer)
        self.button_delete_record.clicked.connect(self.delete_record)

        self.current_table = None
        self.model = None

    def show_products(self):
        db = QSqlDatabase.database()
        if not db.isValid():
            db = QSqlDatabase.addDatabase("QSQLITE")
            db.setDatabaseName("baseforshopuniversam.db")
            db.open()

        self.model = QSqlTableModel(self, db)
        self.model.setTable("Product")
        self.model.select()

        self.model.setHeaderData(0, Qt.Horizontal, "ID")
        self.model.setHeaderData(1, Qt.Horizontal, "Название")
        self.model.setHeaderData(2, Qt.Horizontal, "Цена")
        self.model.setHeaderData(3, Qt.Horizontal, "Скидка")
        self.model.setHeaderData(4, Qt.Horizontal, "ID Группа")
        self.model.setHeaderData(5, Qt.Horizontal, "ID Производитель")

        self.tableView.setModel(self.model)
        self.current_table = "Product"  # Важно: удаление будет из оригинальной таблицы

    def show_manufacturers(self):
        db = QSqlDatabase.database()
        self.model = QSqlTableModel(self, db)
        self.model.setTable("Manufacturer")
        self.model.select()

        self.model.setHeaderData(0, Qt.Horizontal, "ID")
        self.model.setHeaderData(1, Qt.Horizontal, "Название")
        self.model.setHeaderData(2, Qt.Horizontal, "Адрес")

        self.tableView.setModel(self.model)
        self.current_table = "Manufacturer"

    def show_groups(self):
        db = QSqlDatabase.database()
        self.model = QSqlTableModel(self, db)
        self.model.setTable("groupOfProduct")
        self.model.select()

        self.model.setHeaderData(0, Qt.Horizontal, "ID")
        self.model.setHeaderData(1, Qt.Horizontal, "Название группы")

        self.tableView.setModel(self.model)
        self.current_table = "groupOfProduct"

    def delete_record(self):
        index = self.tableView.currentIndex()
        if not index.isValid() or self.model is None:
            QMessageBox.warning(self, "Удаление", "Выберите строку для удаления.")
            return

        row = index.row()
        reply = QMessageBox.question(
            self,
            "Подтверждение",
            f"Вы уверены, что хотите удалить строку из таблицы {self.current_table}?",
            QMessageBox.Yes | QMessageBox.No,
        )

        if reply == QMessageBox.Yes:
            self.model.removeRow(row)
            if self.model.submitAll():
                self.model.select()
            else:
                QMessageBox.critical(self, "Ошибка", "Не удалось удалить запись.")

    def add_product(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Добавить товар")
        layout = QVBoxLayout(dialog)

        name_edit = QLineEdit()
        price_edit = QLineEdit()
        discount_edit = QLineEdit()
        group_combo = QtWidgets.QComboBox()
        manufacturer_combo = QtWidgets.QComboBox()

        # Заполнить группы
        self.cursor.execute("SELECT idgroup, namegroup FROM groupOfProduct")
        groups = self.cursor.fetchall()
        group_map = {}
        for gid, gname in groups:
            group_combo.addItem(gname, gid)
            group_map[gname] = gid

        # Заполнить производителей
        self.cursor.execute("SELECT idManufacturer, nameManufacturer FROM Manufacturer")
        manufacturers = self.cursor.fetchall()
        manufacturer_map = {}
        for mid, mname in manufacturers:
            manufacturer_combo.addItem(mname, mid)
            manufacturer_map[mname] = mid

        layout.addWidget(QLabel("Название:"))
        layout.addWidget(name_edit)
        layout.addWidget(QLabel("Цена:"))
        layout.addWidget(price_edit)
        layout.addWidget(QLabel("Скидка:"))
        layout.addWidget(discount_edit)
        layout.addWidget(QLabel("Группа:"))
        layout.addWidget(group_combo)
        layout.addWidget(QLabel("Производитель:"))
        layout.addWidget(manufacturer_combo)

        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        layout.addWidget(button_box)

        button_box.accepted.connect(dialog.accept)
        button_box.rejected.connect(dialog.reject)

        if dialog.exec() == QDialog.Accepted:
            try:
                name = name_edit.text()
                price = float(price_edit.text())
                discount = float(discount_edit.text())
                group_id = group_combo.currentData()
                manufacturer_id = manufacturer_combo.currentData()

                self.cursor.execute("""
                    INSERT INTO Product (nameProduct, priceProduct, discountProduct, idgroup, idManufacturer)
                    VALUES (?, ?, ?, ?, ?)
                """, (name, price, discount, group_id, manufacturer_id))
                self.db.commit()

                self.show_products()
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось добавить товар:\n{e}")

    def add_group(self):
        name, ok = QtWidgets.QInputDialog.getText(self, "Добавить группу", "Введите название группы:")
        if ok and name:
            self.cursor.execute("INSERT INTO groupOfProduct (namegroup) VALUES (?)", (name,))
            self.db.commit()
            self.show_groups()

    def add_manufacturer(self):
        name, ok1 = QtWidgets.QInputDialog.getText(self, "Название производителя", "Введите название:")
        if not ok1 or not name:
            return

        address, ok2 = QtWidgets.QInputDialog.getText(self, "Адрес", "Введите адрес:")
        if not ok2:
            return

        self.cursor.execute("INSERT INTO Manufacturer (nameManufacturer, address) VALUES (?, ?)", (name, address))
        self.db.commit()
        self.show_manufacturers()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())