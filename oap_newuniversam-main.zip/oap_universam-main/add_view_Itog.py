import sqlite3
from PyQt5 import uic, QtWidgets
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QMainWindow, QTableView, QPushButton,
    QDialog, QVBoxLayout, QLabel, QLineEdit, QDialogButtonBox, QMessageBox, QHBoxLayout
)
from PyQt5.QtSql import QSqlDatabase, QSqlTableModel
from PyQt5.QtGui import QDoubleValidator

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("Builds_designer.ui", self)

        self.db = sqlite3.connect("baseforshopuniversam.db")
        self.cursor = self.db.cursor()

        self.tableView: QTableView = self.findChild(QTableView, "tableView")

        self.button_view_products: QPushButton = self.findChild(QPushButton, "pushButton_view_products")
        self.button_view_manufacturers: QPushButton = self.findChild(QPushButton, "pushButton_view_manufacturers")
        self.button_view_groups: QPushButton = self.findChild(QPushButton, "pushButton_view_groups")
        self.button_add_product: QPushButton = self.findChild(QPushButton, "pushButton_add_product")
        self.button_add_group: QPushButton = self.findChild(QPushButton, "pushButton_add_group")
        self.button_add_manufacturer: QPushButton = self.findChild(QPushButton, "pushButton_add_manufacturer")
        self.button_delete_record: QPushButton = self.findChild(QPushButton, "pushButton_delete_record")

        self.button_search_name: QPushButton = self.findChild(QPushButton, "pushButton_search_name")
        self.button_filter_price: QPushButton = self.findChild(QPushButton, "pushButton_filter_price")

        # Новая кнопка для показа статистики цен
        self.button_show_price_stats: QPushButton = self.findChild(QPushButton, "pushButton_show_price_stats")

        self.button_view_products.clicked.connect(self.show_products)
        self.button_view_manufacturers.clicked.connect(self.show_manufacturers)
        self.button_view_groups.clicked.connect(self.show_groups)
        self.button_add_product.clicked.connect(self.add_product)
        self.button_add_group.clicked.connect(self.add_group)
        self.button_add_manufacturer.clicked.connect(self.add_manufacturer)
        self.button_delete_record.clicked.connect(self.delete_record)

        self.button_search_name.clicked.connect(self.search_name)
        self.button_filter_price.clicked.connect(self.filter_price)
        self.button_show_price_stats = QPushButton("Показать статистику по ценам", self)
        # Можно добавить кнопку куда-то в layout, например, если есть вертикальный layout:
        layout = self.findChild(QtWidgets.QVBoxLayout, "verticalLayout")  # имя layout из ui
        if layout:
            layout.addWidget(self.button_show_price_stats)

        self.button_show_price_stats.clicked.connect(self.show_price_stats)

        self.current_table = None
        self.model = None

    def open_db(self):
        db = QSqlDatabase.database()
        if not db.isValid():
            db = QSqlDatabase.addDatabase("QSQLITE")
            db.setDatabaseName("baseforshopuniversam.db")
            db.open()
        return db

    def show_products(self):
        db = self.open_db()
        self.model = QSqlTableModel(self, db)
        self.model.setTable("Product")
        self.model.select()

        self.model.setHeaderData(0, Qt.Horizontal, "ID")
        self.model.setHeaderData(1, Qt.Horizontal, "Название")
        self.model.setHeaderData(2, Qt.Horizontal, "Цена")
        self.model.setHeaderData(3, Qt.Horizontal, "Скидка")
        self.model.setHeaderData(4, Qt.Horizontal, "ID Группа")
        self.model.setHeaderData(5, Qt.Horizontal, "ID Производитель")

        self.tableView.setModel(self.model)
        self.current_table = "Product"

    def show_manufacturers(self):
        db = self.open_db()
        self.model = QSqlTableModel(self, db)
        self.model.setTable("Manufacturer")
        self.model.select()

        self.model.setHeaderData(0, Qt.Horizontal, "ID")
        self.model.setHeaderData(1, Qt.Horizontal, "Название")
        self.model.setHeaderData(2, Qt.Horizontal, "Адрес")

        self.tableView.setModel(self.model)
        self.current_table = "Manufacturer"

    def show_groups(self):
        db = self.open_db()
        self.model = QSqlTableModel(self, db)
        self.model.setTable("groupOfProduct")
        self.model.select()

        self.model.setHeaderData(0, Qt.Horizontal, "ID")
        self.model.setHeaderData(1, Qt.Horizontal, "Название группы")

        self.tableView.setModel(self.model)
        self.current_table = "groupOfProduct"

    def delete_record(self):
        index = self.tableView.currentIndex()
        if not index.isValid() or self.model is None:
            QMessageBox.warning(self, "Удаление", "Выберите строку для удаления.")
            return

        row = index.row()
        reply = QMessageBox.question(
            self,
            "Подтверждение",
            f"Вы уверены, что хотите удалить строку из таблицы {self.current_table}?",
            QMessageBox.Yes | QMessageBox.No,
        )

        if reply == QMessageBox.Yes:
            self.model.removeRow(row)
            if self.model.submitAll():
                self.model.select()
            else:
                QMessageBox.critical(self, "Ошибка", "Не удалось удалить запись.")

    def add_product(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Добавить товар")
        layout = QVBoxLayout(dialog)

        name_edit = QLineEdit()
        price_edit = QLineEdit()
        discount_edit = QLineEdit()
        group_combo = QtWidgets.QComboBox()
        manufacturer_combo = QtWidgets.QComboBox()

        self.cursor.execute("SELECT idgroup, namegroup FROM groupOfProduct")
        groups = self.cursor.fetchall()
        for gid, gname in groups:
            group_combo.addItem(gname, gid)

        self.cursor.execute("SELECT idManufacturer, nameManufacturer FROM Manufacturer")
        manufacturers = self.cursor.fetchall()
        for mid, mname in manufacturers:
            manufacturer_combo.addItem(mname, mid)

        layout.addWidget(QLabel("Название:"))
        layout.addWidget(name_edit)
        layout.addWidget(QLabel("Цена:"))
        layout.addWidget(price_edit)
        layout.addWidget(QLabel("Скидка:"))
        layout.addWidget(discount_edit)
        layout.addWidget(QLabel("Группа:"))
        layout.addWidget(group_combo)
        layout.addWidget(QLabel("Производитель:"))
        layout.addWidget(manufacturer_combo)

        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        layout.addWidget(button_box)

        button_box.accepted.connect(dialog.accept)
        button_box.rejected.connect(dialog.reject)

        while True:
            if dialog.exec() == QDialog.Accepted:
                name = name_edit.text().strip()
                price_text = price_edit.text().strip()
                discount_text = discount_edit.text().strip()

                if not name:
                    QMessageBox.warning(self, "Ошибка ввода", "Введите название товара.")
                    continue

                try:
                    price = float(price_text)
                    if price < 0:
                        QMessageBox.warning(self, "Ошибка ввода", "Цена не может быть отрицательной.")
                        continue
                except ValueError:
                    QMessageBox.warning(self, "Ошибка ввода", "Введите корректное число в поле цена.")
                    continue

                if discount_text == "":
                    discount = 0.0
                else:
                    try:
                        discount = float(discount_text)
                        if discount < 0 or discount > 100:
                            QMessageBox.warning(self, "Ошибка ввода", "Скидка должна быть от 0 до 100.")
                            continue
                    except ValueError:
                        QMessageBox.warning(self, "Ошибка ввода", "Введите корректное число в поле скидка.")
                        continue

                group_id = group_combo.currentData()
                manufacturer_id = manufacturer_combo.currentData()

                try:
                    self.cursor.execute("""
                        INSERT INTO Product (nameProduct, priceProduct, discountProduct, idgroup, idManufacturer)
                        VALUES (?, ?, ?, ?, ?)
                    """, (name, price, discount, group_id, manufacturer_id))
                    self.db.commit()

                    self.show_products()
                    break
                except Exception as e:
                    QMessageBox.critical(self, "Ошибка", f"Не удалось добавить товар:\n{e}")
                    break
            else:
                break
    def add_group(self):
        name, ok = QtWidgets.QInputDialog.getText(self, "Добавить группу", "Введите название группы:")
        if ok and name:
            self.cursor.execute("INSERT INTO groupOfProduct (namegroup) VALUES (?)", (name,))
            self.db.commit()
            self.show_groups()

    def add_manufacturer(self):
        name, ok1 = QtWidgets.QInputDialog.getText(self, "Название производителя", "Введите название:")
        if not ok1 or not name:
            return

        address, ok2 = QtWidgets.QInputDialog.getText(self, "Адрес", "Введите адрес:")
        if not ok2:
            return

        self.cursor.execute("INSERT INTO Manufacturer (nameManufacturer, address) VALUES (?, ?)", (name, address))
        self.db.commit()
        self.show_manufacturers()

    def search_name(self):
        if self.model is None:
            QMessageBox.warning(self, "Поиск", "Сначала выберите таблицу с названием для поиска.")
            return

        name_column_map = {
            "Product": "nameProduct",
            "Manufacturer": "nameManufacturer",
            "groupOfProduct": "namegroup"
        }
        if self.current_table not in name_column_map:
            QMessageBox.information(self, "Поиск", "Поиск по названию не поддерживается для этой таблицы.")
            return

        name_col = name_column_map[self.current_table]

        text, ok = QtWidgets.QInputDialog.getText(self, "Поиск по названию", "Введите часть названия для поиска:")
        if ok and text:
            filter_str = f"{name_col} LIKE '%{text}%'"
            self.model.setFilter(filter_str)
            self.model.select()
        else:
            self.model.setFilter("")
            self.model.select()

    def filter_price(self):
        if self.current_table != "Product":
            QMessageBox.information(self, "Фильтр по цене", "Фильтрация по цене доступна только для таблицы Товары.")
            return

        dialog = PriceFilterDialog(self)
        if dialog.exec() == QDialog.Accepted:
            min_price, max_price = dialog.get_values()
            filters = []
            if min_price is not None:
                filters.append(f"priceProduct >= {min_price}")
            if max_price is not None:
                filters.append(f"priceProduct <= {max_price}")
            filter_str = " AND ".join(filters)
            self.model.setFilter(filter_str)
            self.model.select()
        else:
            self.model.setFilter("")
            self.model.select()

    def show_price_stats(self):
        # Запрос минимальных и средних цен по группам товаров
        query = """
            SELECT g.namegroup,
                   MIN(p.priceProduct) AS min_price,
                   AVG(p.priceProduct) AS avg_price
            FROM Product p
            JOIN groupOfProduct g ON p.idgroup = g.idgroup
            GROUP BY g.namegroup
        """
        try:
            self.cursor.execute(query)
            results = self.cursor.fetchall()

            if not results:
                QMessageBox.information(self, "Статистика по ценам", "Данные не найдены.")
                return

            text = "Минимальные и средние цены по группам товаров:\n\n"
            for group_name, min_price, avg_price in results:
                text += f"{group_name}: мин. цена = {min_price:.2f}, ср. цена = {avg_price:.2f}\n"

            QMessageBox.information(self, "Статистика по ценам", text)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось получить статистику:\n{e}")


class PriceFilterDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Фильтр по цене")
        layout = QVBoxLayout(self)

        self.min_price_edit = QLineEdit()
        self.min_price_edit.setPlaceholderText("Минимальная цена")
        self.min_price_edit.setValidator(QDoubleValidator(0.0, 9999999.99, 2))

        self.max_price_edit = QLineEdit()
        self.max_price_edit.setPlaceholderText("Максимальная цена")
        self.max_price_edit.setValidator(QDoubleValidator(0.0, 9999999.99, 2))

        layout.addWidget(QLabel("Минимальная цена:"))
        layout.addWidget(self.min_price_edit)
        layout.addWidget(QLabel("Максимальная цена:"))
        layout.addWidget(self.max_price_edit)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def get_values(self):
        min_price = self.min_price_edit.text()
        max_price = self.max_price_edit.text()
        min_price_val = float(min_price) if min_price else None
        max_price_val = float(max_price) if max_price else None
        return min_price_val, max_price_val